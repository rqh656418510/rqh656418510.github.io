package com.clay.demojenkins.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Calendar;

@RestController
@RequestMapping("/user")
public class UserController {

    @GetMapping("/findAll")
    public String findAll() {
        return "hello " + Calendar.getInstance().getTimeInMillis();
    }
}
