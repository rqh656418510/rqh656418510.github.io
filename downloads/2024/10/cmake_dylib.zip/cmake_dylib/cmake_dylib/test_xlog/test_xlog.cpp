﻿#include <iostream>
#include "xlog.h"

using namespace std;

int main() {
	XLog log;
	cout << "test xlog" << endl;
	return 0;
}
