﻿#include <iostream>
#include "xlog.h"

using namespace std;

XLog::XLog() {
	cout << "Create XLog Instance" << endl;
}
