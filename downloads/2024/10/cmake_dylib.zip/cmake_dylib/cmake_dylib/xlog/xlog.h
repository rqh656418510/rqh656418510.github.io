﻿// xlog.h

#ifndef XLOG_H
#define XLOG_H

// 在 Windows 平台编译动态库时：
// __declspec(dllexport) 用于导出 XLog 类的函数到动态库文件中
// __declspec(dllimport) 用于从动态库文件中导入 XLog 类的函数

#ifndef _WIN32
    #define XCPP_API
#else
    #ifdef xlog_EXPORTS
        #define XCPP_API __declspec(dllexport) // 动态库项目的导出
    #else
        #define XCPP_API __declspec(dllimport) // 动态库项目的导入
    #endif
#endif

class XCPP_API XLog {

public:
	XLog();

};

#endif

