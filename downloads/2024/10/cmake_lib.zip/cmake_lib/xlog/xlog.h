// xlog.h

#ifndef XLOG_H
#define XLOG_H

class XLog {

public:
	XLog();

};

#endif

