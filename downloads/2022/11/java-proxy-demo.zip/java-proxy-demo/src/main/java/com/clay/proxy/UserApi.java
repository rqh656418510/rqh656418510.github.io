package com.clay.proxy;

public class UserApi implements IUserApi {
    
    @Override
    public String queryUserInfo() {
        return "Hello Proxy!";
    }
    
}
