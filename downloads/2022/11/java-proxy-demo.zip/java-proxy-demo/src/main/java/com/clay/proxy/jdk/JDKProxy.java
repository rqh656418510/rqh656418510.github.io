package com.clay.proxy.jdk;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class JDKProxy implements InvocationHandler {
    
    Object originalObj;
    
    public Object getProxy(Object originalObj) {
        this.originalObj = originalObj;
        // JDK 动态代理只能为接口创建代理实例
        return Proxy.newProxyInstance(originalObj.getClass().getClassLoader(), originalObj.getClass().getInterfaces(), this);
    }
    
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println(method.getName() + "() 被 JDKProxy 代理了");
        return method.invoke(originalObj, args);
    }
    
}
