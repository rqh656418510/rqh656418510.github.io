package com.clay.proxy;

public interface IUserApi {
    
    String queryUserInfo();
    
}
