package com.clay.proxy;

import com.clay.proxy.asm.AsmClassLoader;
import org.junit.Test;

import java.lang.reflect.Method;

public class AsmProxyTest {
    
    @Test
    public void amsProxyTest() throws Exception {
        AsmClassLoader classLoader = new AsmClassLoader();
        // 生成二进制字节码
        byte[] bytes = classLoader.generateClassBytes();
        // 加载生成的 HelloWorld 类
        Class<?> clazz = classLoader.defineClass("com.proxy.asm.HelloWorld", bytes);
        // 反射获取 main 方法
        Method main = clazz.getMethod("main", String[].class);
        // 调用 main 方法
        main.invoke(null, new Object[] {new String[] {}});
    }

}
