package com.clay.proxy;

import com.clay.proxy.javassist.JavassistProxy;
import org.junit.Test;

public class JavassistProxyTest {
    
    @Test
    public void javassistProxy() throws Exception {
        IUserApi userApi = JavassistProxy.getProxy(UserApi.class);
        String invoke = userApi.queryUserInfo();
        System.out.println("运行结果: " + invoke);
    }
    
}
