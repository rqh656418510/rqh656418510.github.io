package com.clay.proxy;

import com.clay.proxy.bytebuddy.ByteBuddyProxy;
import org.junit.Test;

public class ByteBuddyProxyTest {
    
    @Test
    public void byteBuddyProxy() throws Exception {
        IUserApi userApi = ByteBuddyProxy.getProxy(UserApi.class);
        String invoke = userApi.queryUserInfo();
        System.out.println(invoke);
    }
    
}
