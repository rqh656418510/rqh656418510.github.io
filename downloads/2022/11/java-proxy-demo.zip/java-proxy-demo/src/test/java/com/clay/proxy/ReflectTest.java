package com.clay.proxy;

import org.junit.Test;

import java.lang.reflect.Method;

public class ReflectTest {
    
    @Test
    public void reflect() throws Exception {
        Class<UserApi> clazz = UserApi.class;
        Method queryUserInfo = clazz.getMethod("queryUserInfo");
        Object invoke = queryUserInfo.invoke(clazz.newInstance());
        System.out.println(invoke);
    }
    
}
