package com.clay.proxy;

import com.clay.proxy.cglib.CglibProxy;
import net.sf.cglib.proxy.Enhancer;
import org.junit.Test;

public class CglibProxyTest {
    
    @Test
    public void cglibProxy() {
        Enhancer enhancer = new Enhancer();
        // 设置父类（这里指定的是类，而不是接口）
        enhancer.setSuperclass(UserApi.class);
        // 设置拦截器
        enhancer.setCallback(new CglibProxy());
        // 生成动态代理类
        IUserApi userApi = (UserApi) enhancer.create();
        // 调用类方法
        System.out.println("运行结果: " + userApi.queryUserInfo());
    }
    
}
