package com.clay.proxy;

import com.clay.proxy.jdk.JDKProxy;
import org.junit.Test;

public class JDKProxyTest {
    
    @Test
    public void jdkProxy() {
        IUserApi userApi = (IUserApi) new JDKProxy().getProxy(new UserApi());
        String invoke = userApi.queryUserInfo();
        System.out.println("运行结果: " + invoke);
    }
    
}
