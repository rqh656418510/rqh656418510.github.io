#include "datetime.h"

// 格式化当前时间
// 默认格式是: 2020-06-07 23:46:53
string DateUtil::formatCurrentTime() {
    time_t rawtime;
    struct tm *info;
    char buffer[80];

    time(&rawtime);
    info = localtime(&rawtime);
    strftime(buffer, 80, "%Y-%m-%d %H:%M:%S", info);
    string str(buffer);
    return str;
}

// 格式化当前时间
// format: 格式字符串，例如 %Y-%m-%d %H:%M:%S
string DateUtil::formatCurrentTime(string format) {
    time_t rawtime;
    struct tm *info;
    char buffer[80];

    time(&rawtime);
    info = localtime(&rawtime);
    strftime(buffer, 80, format.c_str(), info);
    string str(buffer);
    return str;
}

// 根据给定的日期，计算它是星期几
// date: 日期字符串，格式是: 2021-12-01
// 返回值：1, 2, 3, 4, 5, 6, 0, 其中 0 表示星期日
int DateUtil::dayOfWeek(const string &date) {
    char c;
    int y, m, d;
    stringstream(date) >> y >> c >> m >> c >> d;
    tm t = {0, 0, 0, d, m - 1, y - 1900};
    mktime(&t);
    return t.tm_wday;
}

// 根据给定的日期，判断是否为周末
// date: 日期字符串，格式是: 2021-12-01
bool DateUtil::isWeekendDays(const string &date) {
    int wday = dayOfWeek(date);
    if (wday == 6 || wday == 0) {
        return true;
    }
    return false;
}
