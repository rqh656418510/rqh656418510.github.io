#pragma once

#include <iostream>

using namespace std;

// 去除字符串两边的空格
void trim(string &str) {
    if (str.empty()) {
        return;
    }
    str.erase(0, str.find_first_not_of(" "));
    str.erase(str.find_last_not_of(" ") + 1);
}