#include <iostream>
#include "strUtil.h"
#include "datetime.h"

using namespace std;

int main() {
    // 去除字符串两边的空格
    string str = " Hello World ! ";
    trim(str);
    cout << str << endl;

    // 根据给定的日期，计算它是星期几
    cout << "wday = " << DateUtil::dayOfWeek("2022-01-11") << ", ";
    cout << "isWeekendDays = " << (DateUtil::isWeekendDays("2022-01-11") ? "true" : "false") << endl;
    return 0;
}