#include <iostream>
#include "strUtil.h"
#include "datetime.h"
#include <gtest/gtest.h>

using namespace std;

// 去除字符串两边的空格
TEST(TestCase, test1) {
    string str = " Hello World ! ";
    trim(str);
    ASSERT_EQ("Hello World !", str);
}

// 根据给定的日期，计算它是星期几
TEST(TestCase, test2) {
    ASSERT_EQ(true, DateUtil::isWeekendDays("2022-01-09"));
}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
