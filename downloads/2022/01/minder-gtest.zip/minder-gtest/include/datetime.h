#pragma once

#include <iostream>
#include <sstream>

using namespace std;

// 日期工具类
class DateUtil {

public:

    static string formatCurrentTime();

    static string formatCurrentTime(string format);

    static int dayOfWeek(const string &date);

    static bool isWeekendDays(const string &date);
};