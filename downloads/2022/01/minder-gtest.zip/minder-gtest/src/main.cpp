#include <iostream>
#include "datetime.h"

using namespace std;

int main() {
    cout << DateUtil::formatCurrentTime() << endl;
    cout << DateUtil::formatCurrentTime("%Y-%m-%d") << endl;
    return 0;
}