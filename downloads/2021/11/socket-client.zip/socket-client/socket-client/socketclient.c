#include "pch.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

// ���庯��ָ�����ͣ��������ݼ���
typedef int (*EncodeData)(unsigned char* in, int inlen, unsigned char* out, int* outlen);

// ����ṹ��
typedef struct _Sck_Handle {
    char version[16];
    char ip[16];
    int port;
    unsigned char* p;
    int len;
    char* p2;
    EncodeData encodeCallback;
} Sck_Handle;

//�ͻ��˳�ʼ��
__declspec(dllexport)
int socketclient_init(void** handle) {
    int ret = 0;
    Sck_Handle* tmpHandle = NULL;

    if (handle == NULL) {
        ret = -1;
        printf("function socketclient_init() err :%d  check params == NULL err \n", ret);
        return ret;
    }

    tmpHandle = (Sck_Handle*)malloc(sizeof(Sck_Handle));
    if (tmpHandle == NULL) {
        ret = -2;
        printf("function socketclient_init() err :%d  malloc err \n", ret);
        return ret;
    }

    memset(tmpHandle, 0, sizeof(Sck_Handle));
    strcpy(tmpHandle->version, "1.0.0.1");
    strcpy(tmpHandle->ip, "192.168.12.12");
    tmpHandle->port = 8081;

    //��Ӹ�ֵ
    *handle = tmpHandle;
    return ret;
}

//�ͻ��˱��ķ���
__declspec(dllexport)
int socketclient_send(void* handle, unsigned char* buf, int buflen) {
    int ret = 0;
    Sck_Handle* tmpHandle = NULL;

    if (handle == NULL || buf == NULL || buflen <= 0) {
        ret = -2;
        printf("function socketclient_send() err :%d  (handle == NULL ||  buf == NULL || buflen <= 0 ) \n", ret);
        return ret;
    }
    tmpHandle = (Sck_Handle*)handle;

    if (tmpHandle->encodeCallback == NULL) {
        //���ķ���
        tmpHandle->len = buflen;
        tmpHandle->p = (unsigned char*)malloc(buflen);
        if (tmpHandle->p == NULL) {
            ret = -2;
            printf("function socketclient_send() err :%d  malloc len:%d \n", ret, buflen);
            return ret;
        }
        memcpy(tmpHandle->p, buf, buflen);
    }
    else {
        //���ܷ���
        unsigned char crypdata[4096];
        int cryptdatalen = 4096;
        ret = tmpHandle->encodeCallback(buf, buflen, crypdata, &cryptdatalen);
        if (ret != 0) {
            printf("function encodeCallback() err :%d  \n", ret);
            return ret;
        }

        tmpHandle->len = cryptdatalen;
        tmpHandle->p = (unsigned char*)malloc(cryptdatalen);
        if (tmpHandle->p == NULL) {
            ret = -1;
            printf("function socketclient_send() err :%d  malloc len:%d \n", ret, cryptdatalen);
            return ret;
        }
        memcpy(tmpHandle->p, crypdata, cryptdatalen);
    }
    return ret;
}

//�ͻ��˱��ļ��ܷ���
__declspec(dllexport)
int socketclient_send_encode(void* handle, unsigned char* buf, int buflen, EncodeData encodeCallback) {
    int ret = 0;
    unsigned char cryptbuf[4096];
    int cryptbuflen = 4096;
    Sck_Handle* tmpHandle = NULL;

    if (handle == NULL || buf == NULL || encodeCallback == NULL) {
        ret = -1;
        printf("function socketclient_send_encode() err :%d  (handle == NULL ||  buf == NULL || encodeCallback == NULL) \n",
            ret);
        return ret;
    }

    // ͨ������ָ�룬ִ�����ݵļ��ܲ���
    ret = encodeCallback(buf, buflen, cryptbuf, &cryptbuflen);
    if (ret != 0) {
        ret = -2;
        printf("function socketclient_send_encode() err :%d  check encode_result == 0 err \n", ret);
        return ret;
    }

    tmpHandle = (Sck_Handle*)handle;
    tmpHandle->len = cryptbuflen;
    tmpHandle->p = (unsigned char*)malloc(cryptbuflen);
    if (tmpHandle->p == NULL) {
        ret = -3;
        printf("function socketclient_send_encode() err :%d  malloc len:%d \n", ret, cryptbuflen);
        return ret;
    }

    //�Ѽ��ܵ����Ļ��浽�ڴ���
    memcpy(tmpHandle->p, cryptbuf, cryptbuflen);

    return 0;
}

//�ͻ��˱��Ľ���
__declspec(dllexport)
int socketclient_recv(void* handle, unsigned char* buf, int* buflen) {
    int ret = 0;
    Sck_Handle* tmpHandle = NULL;

    if (handle == NULL || buf == NULL || buflen == NULL) {
        ret = -2;
        printf("function socketclient_recv() err :%d  (handle == NULL ||  buf == NULL || buflen == NULL ) \n", ret);
        return ret;
    }
    tmpHandle = (Sck_Handle*)handle;

    memcpy(buf, tmpHandle->p, tmpHandle->len);
    *buflen = tmpHandle->len;

    return ret;
}

//�ͻ�����Դ�ͷ�
__declspec(dllexport)
int socketclient_destory(void* handle) {
    int ret = 0;
    Sck_Handle* tmpHandle = NULL;

    if (handle == NULL) {
        return -1;
    }

    tmpHandle = (Sck_Handle*)handle;
    if (tmpHandle->p != NULL) {
        free(tmpHandle->p); //�ͷŽṹ���Ա���ָ����ָ����ڴ�ռ�
    }
    free(tmpHandle); //�ͷŽṹ���ڴ�

    handle = NULL;
    return 0;
}

//���ü��ܻص�����
__declspec(dllexport)
int socketclient_set_encode_callback(void* handle, EncodeData encodeCallback) {
    int ret = 0;
    Sck_Handle* tmpHandle = NULL;
    if (handle == NULL || encodeCallback == NULL) {
        ret = -1;
        printf("function socketclient_set_encode_callback() err :%d  check (handle == NULL || encodeCallback == NULL) err \n", ret);
        return ret;
    }
    tmpHandle = (Sck_Handle*)handle;
    tmpHandle->encodeCallback = encodeCallback;
    return 0;
}