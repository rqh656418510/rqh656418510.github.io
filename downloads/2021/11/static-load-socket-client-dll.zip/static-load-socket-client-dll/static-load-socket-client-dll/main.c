#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "socket-client.h"

int Hw_Encode(unsigned char* in, int inlen, unsigned char* out, int* outlen) {
	printf("function Hw_Encode() begin ....\n");
	strcpy((char*)out, "123456789");
	*outlen = 9;
	printf("function Hw_Encode() end ....\n");
	return 0;
}

int Cisco_Encode(unsigned char* in, int inlen, unsigned char* out, int* outlen) {
	printf("function Cisco_Encode() begin ....\n");
	strcpy((char*)out, "123456789");
	*outlen = 9;
	printf("function Cisco_Encode() end ....\n");
	return 0;
}

int main() {
	unsigned char in[1024];
	int inlen;

	unsigned char out[1024];
	int outlen;

	void* handle = NULL;
	int ret = 0;

	strcpy((char*)in, "aaaaaaaa");
	inlen = 9;

	//�ͻ��˳�ʼ��
	ret = socketclient_init(&handle);
	if (ret != 0)
	{
		printf("function socketclient_init() err:%d \n", ret);
		goto End;
	}
	printf("the result of socketclient_init() is %d \n", ret);

	//���ü��ܻص�����
	ret = socketclient_set_encode_callback(handle, Cisco_Encode);
	if (ret != 0) {
		printf("function socketclient_set_encode_callback() err:%d \n", ret);
	}
	printf("the result of socketclient_set_encode_callback() is %d \n", ret);

	//�ͻ��˷��ͱ���
	ret = socketclient_send(handle, in, inlen);
	if (ret != 0)
	{
		printf("function socketclient_send() err:%d \n", ret);
		goto End;
	}
	printf("the result of socketclient_send() is %d \n", ret);

	//�ͻ��˱��ļ��ܷ���
	ret = socketclient_send_encode(handle, in, inlen, Hw_Encode);
	if (ret != 0)
	{
		printf("function socketclient_send_encode() err:%d \n", ret);
		goto End;
	}
	printf("the result of socketclient_send_encode() is %d \n", ret);

	//�ͻ��˽��ձ���
	ret = socketclient_recv(handle, out, &outlen);
	if (ret != 0)
	{
		printf("function socketclient_recv() err:%d \n", ret);
		goto End;
	}
	printf("the result of socketclient_recv() is %d \n", ret);

End:
	//�ͻ����ͷ���Դ
	ret = socketclient_destory(handle);
	if (ret != 0)
	{
		printf("function socketclient_destory() err:%d \n", ret);
	}
	printf("the result of socketclient_destory() is %d \n", ret);

	return 0;
}