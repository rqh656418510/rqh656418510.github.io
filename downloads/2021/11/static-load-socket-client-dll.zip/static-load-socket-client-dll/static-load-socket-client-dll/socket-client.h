#ifndef _INC_MYSOCKETCLIENT_H__
#define _INC_MYSOCKETCLIENT_H__

#ifdef  __cplusplus
extern "C" {
#endif

	typedef int (*EncodeData)(unsigned char* in, int inlen, unsigned char* out, int* outlen);

	int socketclient_init(void** handle);
	int socketclient_send(void* handle, unsigned char* buf, int buflen);
	int socketclient_recv(void* handle, unsigned char* buf, int* buflen);
	int socketclient_destory(void* handle);
	int socketclient_set_encode_callback(void* handle, EncodeData encodeCallback);
	int socketclient_send_encode(void* handle, unsigned char* buf, int buflen, EncodeData encodeCallback);

#ifdef  __cplusplus
}
#endif

#endif  /* _INC_MYSOCKETCLIENT_H__ */