#include <iostream>
#include <unistd.h>
#include <pthread.h>
#include "pevents.h"

using namespace std;
using namespace neosmart;

neosmart_event_t g_hEvent = NULL;

void printIds(const char *s) {
    pid_t pid = getpid();
    pthread_t tid = pthread_self();
    printf("%s pid %u tid %u (0x%x)\n", s, (unsigned int) pid, (unsigned int) tid, (unsigned int) tid);
}

void *procFunc1(void *args) {
    printIds("thread-1");
    if (WaitForEvent(g_hEvent, 1) == 0) {
        cout << "thread-1 is working..." << endl;
    }
    return ((void *) 0);
}

void *procFunc2(void *args) {
    printIds("thread-2");
    if (WaitForEvent(g_hEvent, 1) == 0) {
        cout << "thread-2 is working..." << endl;
    }
    return ((void *) 0);
}

int main() {
    // �ֶ�����¼��źţ���ʼ״̬Ϊ���ź�
    g_hEvent = CreateEvent(true, true);

    pthread_t ntid1;
    pthread_create(&ntid1, NULL, procFunc1, NULL);

    sleep(1);

    pthread_t ntid2;
    pthread_create(&ntid2, NULL, procFunc2, NULL);

    sleep(5);
}
