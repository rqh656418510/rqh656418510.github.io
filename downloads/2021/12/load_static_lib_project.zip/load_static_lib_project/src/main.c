#include <stdio.h>
#include "static_lib.h"
 
int main(int argc, char *argv[]) {
        info_print();
        return 0;
}
