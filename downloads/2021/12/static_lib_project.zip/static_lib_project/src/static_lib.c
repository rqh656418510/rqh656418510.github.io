#include <stdio.h>
#include "static_lib.h"

void info_print()
{
        printf("hello static library\n");
}
