#ifndef _THIRD_LIB_
#define _THIRD_LIB_
 
void info_print();
 
#endif
