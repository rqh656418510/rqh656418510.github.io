## 注意事项

- 运行注册机软件之前，必须保证断网
- 运行注册机软件之前，必须关闭所有杀毒软件，包括 360 杀毒、腾讯管家、Windows Defender 等
- Navicat Premium 15 安装完成后，不要运行 Navicat 软件，而是直接先运行注册机软件
- 运行注册机软件时，请选择 Navicat 的版本为 `Navicat v15`

