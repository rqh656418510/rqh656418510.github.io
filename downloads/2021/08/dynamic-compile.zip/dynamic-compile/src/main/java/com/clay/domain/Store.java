package com.clay.domain;

/**
 * @author clay
 */
public interface Store {

    public void sell();

}
