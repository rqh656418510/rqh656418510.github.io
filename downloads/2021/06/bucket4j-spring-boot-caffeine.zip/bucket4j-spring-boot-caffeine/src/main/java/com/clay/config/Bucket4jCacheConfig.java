package com.clay.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

/**
 * @author clay
 */
@EnableCaching
@Configuration
public class Bucket4jCacheConfig {

}
