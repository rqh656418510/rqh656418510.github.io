package com.springcloud.study.controller;

import com.springcloud.study.service.SkyFeignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConsumerController {

    @Autowired
    private SkyFeignService providerFeignService;

    @RequestMapping(value = "/getInfo", method = RequestMethod.GET)
    public String getInfo() {
        return providerFeignService.getSendInfo("Consumer-Service");
    }

}
