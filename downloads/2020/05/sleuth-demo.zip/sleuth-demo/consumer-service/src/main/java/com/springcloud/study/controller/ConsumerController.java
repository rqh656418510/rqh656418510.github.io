package com.springcloud.study.controller;

import com.springcloud.study.service.ProviderFeignService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

@RestController
@RequestMapping("/consumer")
public class ConsumerController {

    private static final Logger log = LoggerFactory.getLogger(ConsumerController.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ExecutorService executorService;

    @Autowired
    private ProviderFeignService providerFeignService;

    /**
     * 使用 Feign 来调用
     */
    @GetMapping("/helloByFeign")
    public String helloByFeign(String name) {
        log.info("client sent. Feign 方式, 参数: {}", name);

        String result = providerFeignService.sayHello(name);

        log.info("client received. Feign 方式, 结果: {}", result);
        return result;
    }

    /**
     * 使用 RestTemplate 来调用
     */
    @GetMapping("/helloByRestTemplate")
    public String helloByRestTemplate(String name) {
        log.info("client sent. RestTemplate 方式, 参数: {}", name);

        String url = "http://provider-service/provider/sayHello?name=" + name;
        String result = restTemplate.getForObject(url, String.class);

        log.info("client received. RestTemplate 方式, 结果: {}", result);
        return result;
    }

    /**
     * 创建新线程 + Feign 来调用
     */
    @GetMapping("/helloByNewThread")
    public String hello(String name) throws ExecutionException, InterruptedException {
        log.info("client sent. 子线程方式, 参数: {}", name);

        Future future = executorService.submit(() -> {
            log.info("client sent. 进入子线程, 参数: {}", name);
            String result = providerFeignService.sayHello(name);
            return result;
        });

        String result = (String) future.get();
        log.info("client received. 返回主线程, 结果: {}", result);
        return result;
    }

}
