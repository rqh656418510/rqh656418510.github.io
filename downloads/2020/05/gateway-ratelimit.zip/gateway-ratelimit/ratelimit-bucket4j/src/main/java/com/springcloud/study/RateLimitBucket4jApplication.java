package com.springcloud.study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RateLimitBucket4jApplication {

    public static void main(String[] args) {
        SpringApplication.run(RateLimitBucket4jApplication.class, args);
    }
}
