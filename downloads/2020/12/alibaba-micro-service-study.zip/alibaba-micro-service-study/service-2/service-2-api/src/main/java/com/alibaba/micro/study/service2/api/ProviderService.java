package com.alibaba.micro.study.service2.api;

/**
 * @author clay
 */
public interface ProviderService {

    public String add(Integer a, Integer b);

    public String sub(Integer a, Integer b);
}
