package com.alibaba.micro.study.servcie1.api;

/**
 * @author clay
 */
public interface ConsumerService {

    public String add(Integer a, Integer b);
}
