package com.seata.study.domain;

import com.seata.study.enums.OrderStatus;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author clay
 * @version 1.0
 */
public class Order implements Serializable {

    /**
     * 订单ID
     */
    private Long id;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 商品ID
     */
    private Long productId;

    /**
     * 商品数量
     */
    private Long count;

    /**
     * 付款金额
     */
    private BigDecimal money;

    /**
     * 订单状态
     */
    private Integer status = OrderStatus.CREATING.getValue();

    public Order() {

    }

    public Order(Long id, Long userId, Long productId, Long count, BigDecimal money, Integer status) {
        this.id = id;
        this.userId = userId;
        this.productId = productId;
        this.count = count;
        this.money = money;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
