package com.springcloud.study.controller;

import com.springcloud.study.domain.User;
import com.springcloud.study.service.ICollapsingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.Future;

@RestController
@RequestMapping("/user")
public class CollapsingController {

    private static final Logger logger = LoggerFactory.getLogger(CollapsingController.class);

    @Autowired
    private ICollapsingService collapsingService;

    /**
     * 请求聚合/合并
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/getUser")
    public String getUser() throws Exception {
        Future<User> user = collapsingService.collapsing(1);
        Future<User> user2 = collapsingService.collapsing(2);
        logger.info(user.get().getUserName());
        logger.info(user2.get().getUserName());
        return "Success";
    }

    /**
     * 请求聚合/合并,整个应用的
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/getUserGolbal")
    public String getUserGolbal() throws Exception {
        Future<User> user = collapsingService.collapsingGlobal(1);
        Future<User> user2 = collapsingService.collapsingGlobal(2);
        logger.info(user.get().getUserName());
        logger.info(user2.get().getUserName());
        return "Success";
    }
}
