package com.springcloud.study.service;

import com.springcloud.study.domain.User;

import java.util.concurrent.Future;

public interface ICollapsingService {

    public Future<User> collapsing(Integer id);

    public Future<User> collapsingGlobal(Integer id);

}
