package com.springcloud.study.service;

import com.netflix.hystrix.HystrixCollapser.Scope;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCollapser;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.springcloud.study.domain.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

@Service
public class CollapsingService implements ICollapsingService {

    private static final Logger logger = LoggerFactory.getLogger(CollapsingService.class);

    @HystrixCollapser(batchMethod = "collapsingList", collapserProperties = {
            @HystrixProperty(name = "timerDelayInMilliseconds", value = "1000")
    })
    public Future<User> collapsing(Integer id) {
        return null;
    }

    @HystrixCollapser(batchMethod = "collapsingListGlobal", scope = Scope.GLOBAL, collapserProperties = {
            @HystrixProperty(name = "timerDelayInMilliseconds", value = "10000")
    })
    public Future<User> collapsingGlobal(Integer id) {
        return null;
    }

    @HystrixCommand
    public List<User> collapsingList(List<Integer> userParam) {
        logger.info("collapsingList当前线程: " + Thread.currentThread().getName());
        logger.info("当前请求参数个数:" + userParam.size());
        List<User> userList = new ArrayList<User>();
        for (Integer userNumber : userParam) {
            User user = new User();
            user.setUserName("User - " + userNumber);
            user.setAge(userNumber);
            userList.add(user);
        }
        return userList;
    }

    @HystrixCommand
    public List<User> collapsingListGlobal(List<Integer> userParam) {
        logger.info("collapsingListGlobal当前线程: " + Thread.currentThread().getName());
        logger.info("当前请求参数个数:" + userParam.size());
        List<User> userList = new ArrayList<User>();
        for (Integer userNumber : userParam) {
            User user = new User();
            user.setUserName("User- " + userNumber);
            user.setAge(userNumber);
            userList.add(user);
        }
        return userList;
    }

}
