package com.springcloud.study.config;

public class HystrixThreadLocal {

    public static ThreadLocal<String> threadLocal = new ThreadLocal<>();
}
