package com.springcloud.study.controller;

import com.springcloud.study.service.ProviderClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CalculateController {

    @Autowired
    private ProviderClientService clientService;

    @GetMapping("/say")
    public String say(String msg){
        return clientService.say(msg);
    }

    @GetMapping("/add")
    public String add(Integer a, Integer b){
        return clientService.add(a, b);
    }

}
