package com.springcloud.study.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value = "PROVIDER")
public interface ProviderClientService {

    @GetMapping("/provider/say")
    String say(@RequestParam("msg") String msg);

    @GetMapping("/provider/add")
    String add(@RequestParam("a") Integer a, @RequestParam("b") Integer b);

}
